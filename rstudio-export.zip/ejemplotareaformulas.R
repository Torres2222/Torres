---
title: "pagina de prueba para la tarea"
author: "Angel Torres Renero "
editor: visual 
---
  
  #Ejemplo de uno de mis formulas: 
En este ejemplo carga mis formulas de interes simple desde mi repitorio de [github]()

#se cargan las funciones de manera remota: 

https://github.com/Torres2222/Torres/upload/main

source(https://github.com/Torres2222/Torres/edit/main/README.simple.R)